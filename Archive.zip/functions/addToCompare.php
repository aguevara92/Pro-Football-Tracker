<?php

	if (session_status() == PHP_SESSION_NONE) {
	    session_start();
	}

	// Attempt insert query execution
	if (!isset($_SESSION["CompareList"])){
		$_SESSION["CompareList"] = array();
	}

	// if there are less than 2 players in the list
	if (count($_SESSION["CompareList"]) < 2){
		if(isset($_SESSION["CompareList"][$_POST["email"]])){
			echo "already in compare list";
		} else {
			$_SESSION["CompareList"][$_POST["email"]] = $_POST["email"];
			echo "agregaste a " .$_POST["email"];
		}
	} else {
		echo "ya tienes dos jugadores en la lista = " . count($_SESSION["CompareList"]);
	}

?>