<h1 class="break-title">Tests</h1>

<div class="tests-buttons">

	<div class="col-md-4">
		<a href="best_test.php?test=jump_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r1_c1.png">
				<h2>Jump Test</h2>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="best_test.php?test=aerobic_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r1_c1.png">
				<h2>Aerobic Test</h2>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="best_test.php?test=sprint_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r1_c5.png">
				<h2>Sprint Test</h2>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="best_test.php?test=psychology_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r2_c1.png">
				<h2><span>Psychology</span> Test</h2>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="best_test.php?test=agility_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r2_c3.png">
				<h2>Agility Test</h2>
			</div>
		</a>
	</div>

	<div class="col-md-4">
		<a href="best_test.php?test=balance_tests">
			<div class="clearfix">
				<img src="images/icons/tests-icons_r2_c5.png">
				<h2>Balance Test</h2>
			</div>
		</a>
	</div>

</div>