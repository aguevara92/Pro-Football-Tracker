<a href="players.php">
	<div class="btn-view-all-player">
		<h1>View all the players</h1>
	</div>
</a>