<h1 class="table-title">You want to be in NAME OF APP</h1>
<p>If you are a football player you can register FOR FREE</p>
<p> Just click on the button below to create you new account and get known by recruiters</p>
<a href="register_player.php" class="btn btn-large">Create an account for free</a>

<p>If you have already created your app you can <a href="login.php" class="btn btn-small">Login</a></p>