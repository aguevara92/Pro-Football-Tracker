<h1 class="break-title">Best ranked players</h1>

<div class="carrousel">
	<div>
		<?
		$loop = $query->GetOrdered("users","overall_ranking","DESC",7);
		foreach ($loop as $i){ ?>
			<div class="">

					<?php /** PROFILE PIC --- */
					require 'inc/print-profile-pic.php';?>
				
					<a href='player.php?email=<?php echo $i["email"];?>'><h3><?php echo $i["first_name"];?> <?php echo $i["last_name"];?></h3></a>
					<h6><?php echo $i["team"];?></h6>
				
					<h1><?php echo $i["overall_ranking"];?></h1>
				
			</div>
		<?php } ?>
	</div>
    <span id="prev" class="flaticon-arrow-left"></span>
    <span id="next" class="flaticon-arrow-right"></span>
</div>
<a href="players.php" class="btn btn-centered btn-primary">View all the players</a>

<script src="js/slick.js"></script>