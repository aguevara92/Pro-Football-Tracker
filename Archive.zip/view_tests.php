<?php	
require 'header.php';
$query = new Queries(); // $pdo,table
?>

<div class="container">
	<div class="row">
		<?php /** TESTS RANKING TAB --- */
		require 'inc/frontpage-tests-buttons.php';?>
	</div>
</div>




<?php
require 'footer.php'; // layout
?>