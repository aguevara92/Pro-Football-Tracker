				</div>
			</div>         
    	</main> 
	</body>

		<!-- LOAD JS FILES -->
	    <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	    <script src="js/cookies.js"></script>
	    <!-- <script src="js/masonry.js"></script> -->
	    <script src="js/matchHeight.js"></script>
	    <script src="js/scripts.js"></script>
</html>